import base64
import json                    
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import requests
import os
import glob

api='http://f27c-195-130-59-184.ngrok.io/upload-image'
data_old = 1
while True:
	data_new = len(os.listdir("/home/etftk/projects/TSI"))
	if (data_new != data_old):
		folder_path = r'/home/etftk/projects/TSI'
		file_type = '/*jpg'
		files = glob.glob(folder_path + file_type)
		max_file = max(files, key=os.path.getctime)
		print (max_file)
		print(data_new)
		data_old = data_new
		image_file = max_file
		with open(image_file, "rb") as f:
		    im_bytes = f.read()        
		im_b64 = base64.b64encode(im_bytes).decode("utf8")

		headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
		  
		payload = json.dumps({"image": im_b64, "other_key": "value"})
		response = requests.post(api, data=payload, headers=headers)
		try:
		    data = response.json()     
		    print(data)
		    files = open('/home/etftk/projects/tablica.txt', 'w');
		    files.write(str(data));
		    files.close();                
		except requests.exceptions.RequestException:
		    print(response.text)
