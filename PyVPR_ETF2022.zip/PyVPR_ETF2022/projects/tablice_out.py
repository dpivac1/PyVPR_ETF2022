import datetime
import requests

url ='http://e37e-195-130-59-184.ngrok.io/upload-out'
while True:
	with open('tablica_out.txt') as f:
 		tablice = f.read()
	if tablice != '':
		date_time=tablice[44:len(tablice)-2]    
		licence_plate=tablice[13:22]
		tablice_out = {}
		tablice_out ["tablica"] = licence_plate
		tablice_out ["vrijemeDolaska"]=date_time
		x = requests.post (url,data=str(tablice));
		tablice_out ["vrijemeOdlaska"]=str(datetime.datetime.now());
		print(str(tablice_out))
		files = open('tablica_out.txt', 'w');
		files.write("");
		files.close();
		
