from catalogplates.models import Tablice
import datetime

with open('tablica_in.txt') as f:
	licence_plate = f.read()

date_time=licence_plate[44:len(licence_plate)-2]    
licence_plate=licence_plate[13:22]
licence = Tablice(brojTablica=licence_plate,vrijemeDolaska=date_time)
licence.save()
