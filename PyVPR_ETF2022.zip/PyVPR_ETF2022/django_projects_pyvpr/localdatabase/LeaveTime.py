from catalogplates.models import Tablice
import datetime

with open('tablica_out.txt') as f:
	licence_plate = f.read()
date_time=licence_plate[44:len(licence_plate)-2]    
licence_plate=licence_plate[13:22]
licence = Tablice.objects.get(brojTablica=licence_plate)
date_time_leave = datetime.datetime.now()
licence.vrijemeOdlaska = date_time_leave
licence.save()
files = open('tablice.txt', 'a');
files.write(str({'tablice': licence_plate,'vrijemeDolaska': date_time, 'vrijemeOdlaska': str(date_time_leave)}))
files.write('\n')
files.close();
Tablice.objects.filter(brojTablica=licence_plate).delete()
