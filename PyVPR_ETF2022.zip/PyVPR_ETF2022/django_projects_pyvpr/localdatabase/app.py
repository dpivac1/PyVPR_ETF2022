from flask import Flask, Response, request
import subprocess

app = Flask(__name__)

@app.route('/')
@app.route('/home')
def home():
    return "<h1>Home Page<h1>"

@app.route('/about')
def about():
    return "<h1>About Page<h1>""This API has a task to add received licence plate to database with timestamp or remove it if a car with said licence plate has left."

@app.route('/upload-in', methods=['POST', 'GET'])
def get_data1():
	if request.method == 'POST':
		data1=str(request.data)
		data1=data1[2:len(data1)-1]
		files = open('tablica_in.txt', 'w');
		files.write(str(data1));
		files.close();
		print('Recieved from client: {}'.format(str(data1)))
		subprocess.call('/home/etftk/django_projects_pyvpr/localdatabase/bash_in.sh')
	return Response('<h1>We recieved arriving licence plate<h1>')
    
@app.route('/upload-out', methods=['POST', 'GET'])
def get_data2():
	if request.method == 'POST':
		data2=str(request.data)
		data2=data2[2:len(data2)-1]
		files = open('tablica_out.txt', 'w');
		files.write(str(data2));
		files.close();
		subprocess.call('/home/etftk/django_projects_pyvpr/localdatabase/bash_out.sh')
	return Response('<h1>We recieved leaving licence plate<h1>')


if __name__ == '__main__':
    app.run(debug=True)
