#!/bin/bash

python3 manage.py shell < CreateLicencePlate.py
