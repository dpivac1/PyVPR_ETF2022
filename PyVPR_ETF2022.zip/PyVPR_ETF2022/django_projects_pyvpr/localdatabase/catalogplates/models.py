from django.db import models

class VrstaTablica(models.Model):
    vrsta = models.CharField(max_length=100, help_text='Unesite vrstu tablica (npr. bh, hr taksi...)')

    def __str__(self):
        """String for representing the Model object."""
        return self.vrsta
        #return 'test'
        
    #def get_absolute_url(self):
        """Returns the url to access a detail record for this book."""
        return reverse('vrsta-detail', args=[str(self.id)])
        

from django.urls import reverse # Used to generate URLs by reversing the URL patterns
import datetime

class Tablice(models.Model):

    vlasnik = models.ForeignKey('Vlasnik', default='', blank=True, on_delete=models.SET_NULL, null=True)

    brojTablica = models.CharField('Broj tablica', max_length=9, unique=True,
                             help_text='Unesite broj tablica')

    oznakaTablica = models.ForeignKey('VrstaTablica', default='', blank=True, on_delete=models.SET_NULL, null=True)
    
    modelVozila= models.ForeignKey('ModelVozila',default='', blank=True, on_delete=models.SET_NULL, null=True)
    
    vrijemeDolaska=models.TimeField(auto_now_add=True,blank=True)
    vrijemeOdlaska=models.TimeField(auto_now_add=True,blank=True)
    

    def __str__(self):
        """String for representing the Model object."""
        return self.brojTablica

    def get_absolute_url(self):
        """Returns the url to access a detail record for this book."""
        return reverse('tablice-detail', args=[str(self.id)])

class Vlasnik(models.Model):

    ime = models.CharField(max_length=100)
    prezime = models.CharField(max_length=100)

    class Meta:
        ordering = ['ime', 'prezime']

    def get_absolute_url(self):
        return reverse('vlasnik-detail', args=[str(self.id)])

    def __str__(self):
        return f'{self.prezime}, {self.ime}'


class ModelVozila(models.Model):

    markaVozila = models.CharField(max_length=100)
    vazecaRegistracija=models.BooleanField()
    
    def __str__(self):
        
       return self.markaVozila
       
class Vremena(models.Model):

    vrijemeDolaska=models.TimeField(auto_now_add=True,blank=True)
    vrijemeOdlaska=models.TimeField(auto_now_add=True,blank=True)
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

# Create your models here.
