from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('baza/', views.DatabaseListView.as_view(), name='baza'),
    path('baza/<int:pk>', views.DatabaseDetailView.as_view(), name='tablice-detail'),
]

urlpatterns += [
    path('bazalog/', views.DatabaseLogListView.as_view(), name='bazalog'),
]
