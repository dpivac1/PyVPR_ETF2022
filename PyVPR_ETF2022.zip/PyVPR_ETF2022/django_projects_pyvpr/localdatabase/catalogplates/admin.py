from django.contrib import admin

# Register your models here.

from .models import Vlasnik, VrstaTablica, Tablice, ModelVozila, Vremena



# Define the admin class
class VlasnikAdmin(admin.ModelAdmin):
    pass
admin.site.register(Vlasnik, VlasnikAdmin)

class ModelVozilaAdmin(admin.ModelAdmin):
    pass
admin.site.register(ModelVozila, ModelVozilaAdmin)

class VrstaTablicaAdmin(admin.ModelAdmin):
    pass
admin.site.register(VrstaTablica, VrstaTablicaAdmin)

class VremenaAdmin(admin.ModelAdmin):
    pass
admin.site.register(Vremena, VremenaAdmin)
    

@admin.register(Tablice)
class TabliceAdmin(admin.ModelAdmin):
    list_display = ('brojTablica', 'vlasnik')


# Register the Admin classes for BookInstance using the decorator
#@admin.register(VrstaTablica)
#class VrstaTablicaAdmin(admin.ModelAdmin):
#    pass

