#!/bin/bash

python3 PredictCharacters.py
