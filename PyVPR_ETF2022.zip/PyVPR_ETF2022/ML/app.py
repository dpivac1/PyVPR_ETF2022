from flask import Flask, jsonify, request, abort
import os
import subprocess
#import threading
import io
import json   
import time                 
import base64                  
import logging             
import numpy as np
from PIL import Image

app = Flask(__name__)

@app.route('/')
@app.route('/home')
def home():
    return "<h1>Home Page<h1>"

@app.route('/about')
def about():
	
    return "<h1>About Page<h1>""This API is meant to receive images and run ML model and if licence plate can be red then API uploads it to API for adding or removing data from database"

@app.route("/upload-image", methods=["POST"])
def test_method():         
    ## print(request.json)      
    if not request.json or 'image' not in request.json: 
        abort(400)
             
    # get the base64 encoded string
    im_b64 = request.json['image']

    # convert it into bytes  
    img_bytes = base64.b64decode(im_b64.encode('utf-8'))

    # convert bytes data to PIL Image object
    img = Image.open(io.BytesIO(img_bytes))

    # PIL image object to numpy array
    img_arr = np.asarray(img)      
    print('img shape', img_arr.shape)

    # process your img_arr here    
    img.save('15.jpg')
    subprocess.call('/home/etftk/projects/simple-flask-api/bash.sh')
    with open('tablica_in.txt') as f:
    	licence_plate = f.read()
    # access other keys of json
    # print(request.json['other_key'])

    result_dict = {'tablica': licence_plate[13:22],'vrijemeDolaska': licence_plate[44:len(licence_plate)-2]}
    return result_dict
    
if __name__ == '__main__':
        app.run(debug=True)
