import SegmentCharacters
import pickle
import datetime
import requests
print("Loading model")
filename = './finalized_model.sav'
model = pickle.load(open(filename, 'rb'))

print('Model loaded. Predicting characters of number plate')
classification_result = []
for each_character in SegmentCharacters.characters:
    # converts it to a 1D array
    each_character = each_character.reshape(1, -1);
    result = model.predict(each_character)
    classification_result.append(result)

print('Classification result')
print(classification_result)

plate_string = ''
for eachPredict in classification_result:
    plate_string += eachPredict[0]

print('Predicted license plate')
print(plate_string)

# it's possible the characters are wrongly arranged
# since that's a possibility, the column_list will be
# used to sort the letters in the right order

column_list_copy = SegmentCharacters.column_list[:]
SegmentCharacters.column_list.sort()
rightplate_string = ''
for each in SegmentCharacters.column_list:
    rightplate_string += plate_string[column_list_copy.index(each)]

print('License plate')

if (len(rightplate_string)) == 8:
   plate_string=rightplate_string[1:]
elif len(rightplate_string) != 7:
   print("Greska: Tablica nije ispravno ocitana")
   quit()
else: 
   plate_string=rightplate_string
   
 
final_plate_string = plate_string[0:3] + '-' + plate_string[3]  + '-' + plate_string[4:7]
 
 
print(final_plate_string)
 
url ='http://e37e-195-130-59-184.ngrok.io/upload-in'
tablice = {};
tablice ["tablica"] = final_plate_string
tablice ["vrijemeDolaska"]=str(datetime.datetime.now());
print(tablice)
files = open('tablica_in.txt', 'w');
files.write(str(tablice));
files.close();
x = requests.post (url,data=str(tablice));
